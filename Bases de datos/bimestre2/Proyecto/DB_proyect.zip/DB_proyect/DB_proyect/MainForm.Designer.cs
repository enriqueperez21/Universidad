﻿namespace DB_proyect
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            sub_windows = new TabControl();
            tabPage1 = new TabPage();
            comboBox_table_selected = new ComboBox();
            label2 = new Label();
            dataGridView1 = new DataGridView();
            tabPage2 = new TabPage();
            label3 = new Label();
            tabControl1 = new TabControl();
            tabUpdateAgencias = new TabPage();
            update_agencias_new_address = new TextBox();
            label41 = new Label();
            update_agencias_new_name = new TextBox();
            label42 = new Label();
            button_update_agencia = new Button();
            label14 = new Label();
            update_agencias_old_name = new TextBox();
            label15 = new Label();
            tabUpdateClientes = new TabPage();
            update_client_new_dni_avalador = new TextBox();
            label43 = new Label();
            update_client_new_phone = new TextBox();
            label44 = new Label();
            update_client_new_address = new TextBox();
            label45 = new Label();
            update_client_dni = new TextBox();
            label46 = new Label();
            button_update_client = new Button();
            label47 = new Label();
            update_client_new_name = new TextBox();
            label48 = new Label();
            tabUpdateCoches = new TabPage();
            update_car_id = new TextBox();
            label55 = new Label();
            update_car_new_marca = new TextBox();
            label49 = new Label();
            update_car_new_color = new TextBox();
            label50 = new Label();
            update_car_new_model = new TextBox();
            label51 = new Label();
            update_car_new_matricula = new TextBox();
            label52 = new Label();
            button_update_car = new Button();
            label53 = new Label();
            update_car_new_garage = new TextBox();
            label54 = new Label();
            tabUpdateReservas = new TabPage();
            label68 = new Label();
            label64 = new Label();
            label63 = new Label();
            update_reservas_id = new TextBox();
            label62 = new Label();
            update_reservas_new_agencia_name = new TextBox();
            label56 = new Label();
            update_reservas_new_cost = new TextBox();
            label57 = new Label();
            update_reservas_new_end_date = new TextBox();
            label58 = new Label();
            update_reservas_new_dni_client = new TextBox();
            label59 = new Label();
            button_update_reservas = new Button();
            label60 = new Label();
            update_reservas_new_begin_date = new TextBox();
            label61 = new Label();
            tabPage3 = new TabPage();
            label4 = new Label();
            tabControl2 = new TabControl();
            tabPage5 = new TabPage();
            insert_agencia_address = new TextBox();
            label17 = new Label();
            insert_agencia = new Button();
            label18 = new Label();
            insert_agencia_name = new TextBox();
            label19 = new Label();
            tabPage6 = new TabPage();
            insert_cliente_avalador = new TextBox();
            label25 = new Label();
            insert_cliente_phone = new TextBox();
            label26 = new Label();
            insert_cliente_address = new TextBox();
            label27 = new Label();
            insert_cliente_dni = new TextBox();
            label28 = new Label();
            button_insert_cliente = new Button();
            label29 = new Label();
            insert_cliente_name = new TextBox();
            label30 = new Label();
            tabPage7 = new TabPage();
            insert_coches_marca = new TextBox();
            label24 = new Label();
            insert_coches_color = new TextBox();
            label23 = new Label();
            insert_coches_modelo = new TextBox();
            label22 = new Label();
            insert_coches_matricula = new TextBox();
            label16 = new Label();
            button2 = new Button();
            label20 = new Label();
            insert_coches_garaje = new TextBox();
            label21 = new Label();
            tabPage8 = new TabPage();
            label69 = new Label();
            label66 = new Label();
            label65 = new Label();
            insert_reserva_agencia_name = new TextBox();
            label31 = new Label();
            insert_reserva_costo = new TextBox();
            label32 = new Label();
            insert_reserva_final_date = new TextBox();
            label33 = new Label();
            insert_reserva_dni_client = new TextBox();
            label34 = new Label();
            button_insert_reserva = new Button();
            label35 = new Label();
            insert_reserva_begin_date = new TextBox();
            label36 = new Label();
            tabPage4 = new TabPage();
            label5 = new Label();
            tabControl3 = new TabControl();
            tabPage9 = new TabPage();
            button_delete_agencia = new Button();
            label9 = new Label();
            delete_agencia_name = new TextBox();
            label10 = new Label();
            label11 = new Label();
            tabPage10 = new TabPage();
            delete_clientes = new Button();
            label8 = new Label();
            delete_name_cliente = new TextBox();
            delete_dni_cliente = new TextBox();
            label7 = new Label();
            label6 = new Label();
            tabPage11 = new TabPage();
            button_delete_coche = new Button();
            label12 = new Label();
            delete_coche_matricula = new TextBox();
            label13 = new Label();
            tabPage12 = new TabPage();
            label67 = new Label();
            delete_reserva_agencia_name = new TextBox();
            label37 = new Label();
            delete_reserva_dni_cliente = new TextBox();
            label38 = new Label();
            button3 = new Button();
            label39 = new Label();
            delete_reserva_begin_date = new TextBox();
            label40 = new Label();
            sub_windows.SuspendLayout();
            tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            tabPage2.SuspendLayout();
            tabControl1.SuspendLayout();
            tabUpdateAgencias.SuspendLayout();
            tabUpdateClientes.SuspendLayout();
            tabUpdateCoches.SuspendLayout();
            tabUpdateReservas.SuspendLayout();
            tabPage3.SuspendLayout();
            tabControl2.SuspendLayout();
            tabPage5.SuspendLayout();
            tabPage6.SuspendLayout();
            tabPage7.SuspendLayout();
            tabPage8.SuspendLayout();
            tabPage4.SuspendLayout();
            tabControl3.SuspendLayout();
            tabPage9.SuspendLayout();
            tabPage10.SuspendLayout();
            tabPage11.SuspendLayout();
            tabPage12.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(83, 20);
            label1.TabIndex = 0;
            label1.Text = "Bienvenido";
            // 
            // sub_windows
            // 
            sub_windows.Controls.Add(tabPage1);
            sub_windows.Controls.Add(tabPage2);
            sub_windows.Controls.Add(tabPage3);
            sub_windows.Controls.Add(tabPage4);
            sub_windows.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            sub_windows.Location = new Point(12, 51);
            sub_windows.Multiline = true;
            sub_windows.Name = "sub_windows";
            sub_windows.SelectedIndex = 0;
            sub_windows.Size = new Size(1204, 629);
            sub_windows.TabIndex = 2;
            // 
            // tabPage1
            // 
            tabPage1.BackColor = SystemColors.Control;
            tabPage1.Controls.Add(comboBox_table_selected);
            tabPage1.Controls.Add(label2);
            tabPage1.Controls.Add(dataGridView1);
            tabPage1.Location = new Point(4, 37);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(1196, 588);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Registros";
            // 
            // comboBox_table_selected
            // 
            comboBox_table_selected.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox_table_selected.FormattingEnabled = true;
            comboBox_table_selected.Items.AddRange(new object[] { "Agencias", "Clientes", "Coches", "Reservas" });
            comboBox_table_selected.Location = new Point(20, 55);
            comboBox_table_selected.Name = "comboBox_table_selected";
            comboBox_table_selected.Size = new Size(151, 36);
            comboBox_table_selected.TabIndex = 5;
            comboBox_table_selected.SelectedIndexChanged += comboBox_table_selected_SelectedIndexChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(463, 22);
            label2.Name = "label2";
            label2.Size = new Size(257, 28);
            label2.TabIndex = 3;
            label2.Text = "Consultas a la base de datos";
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToOrderColumns = true;
            dataGridView1.AllowUserToResizeColumns = false;
            dataGridView1.AllowUserToResizeRows = false;
            dataGridView1.BackgroundColor = SystemColors.Control;
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Dock = DockStyle.Bottom;
            dataGridView1.Location = new Point(3, 106);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(1190, 479);
            dataGridView1.TabIndex = 2;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(label3);
            tabPage2.Controls.Add(tabControl1);
            tabPage2.Location = new Point(4, 37);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(1196, 588);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Actualizar datos";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(497, 22);
            label3.Name = "label3";
            label3.Size = new Size(154, 28);
            label3.TabIndex = 1;
            label3.Text = "Actualizar Datos";
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabUpdateAgencias);
            tabControl1.Controls.Add(tabUpdateClientes);
            tabControl1.Controls.Add(tabUpdateCoches);
            tabControl1.Controls.Add(tabUpdateReservas);
            tabControl1.Location = new Point(27, 83);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1142, 500);
            tabControl1.TabIndex = 0;
            // 
            // tabUpdateAgencias
            // 
            tabUpdateAgencias.Controls.Add(update_agencias_new_address);
            tabUpdateAgencias.Controls.Add(label41);
            tabUpdateAgencias.Controls.Add(update_agencias_new_name);
            tabUpdateAgencias.Controls.Add(label42);
            tabUpdateAgencias.Controls.Add(button_update_agencia);
            tabUpdateAgencias.Controls.Add(label14);
            tabUpdateAgencias.Controls.Add(update_agencias_old_name);
            tabUpdateAgencias.Controls.Add(label15);
            tabUpdateAgencias.Location = new Point(4, 37);
            tabUpdateAgencias.Name = "tabUpdateAgencias";
            tabUpdateAgencias.Padding = new Padding(3);
            tabUpdateAgencias.Size = new Size(1134, 459);
            tabUpdateAgencias.TabIndex = 0;
            tabUpdateAgencias.Text = "Agencias";
            tabUpdateAgencias.UseVisualStyleBackColor = true;
            // 
            // update_agencias_new_address
            // 
            update_agencias_new_address.Location = new Point(556, 274);
            update_agencias_new_address.Name = "update_agencias_new_address";
            update_agencias_new_address.Size = new Size(276, 34);
            update_agencias_new_address.TabIndex = 31;
            // 
            // label41
            // 
            label41.AutoSize = true;
            label41.Location = new Point(362, 277);
            label41.Name = "label41";
            label41.Size = new Size(153, 28);
            label41.TabIndex = 30;
            label41.Text = "Nueva dirección";
            // 
            // update_agencias_new_name
            // 
            update_agencias_new_name.Location = new Point(556, 210);
            update_agencias_new_name.Name = "update_agencias_new_name";
            update_agencias_new_name.Size = new Size(276, 34);
            update_agencias_new_name.TabIndex = 29;
            // 
            // label42
            // 
            label42.AutoSize = true;
            label42.Location = new Point(252, 210);
            label42.Name = "label42";
            label42.Size = new Size(263, 28);
            label42.TabIndex = 28;
            label42.Text = "Nuevo nombre de la agencia";
            // 
            // button_update_agencia
            // 
            button_update_agencia.Location = new Point(479, 391);
            button_update_agencia.Name = "button_update_agencia";
            button_update_agencia.Size = new Size(182, 42);
            button_update_agencia.TabIndex = 19;
            button_update_agencia.Text = "Actualizar agencia";
            button_update_agencia.UseVisualStyleBackColor = true;
            button_update_agencia.Click += button_update_agencia_Click;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(518, 44);
            label14.Name = "label14";
            label14.Size = new Size(90, 28);
            label14.TabIndex = 18;
            label14.Text = "Agencias";
            // 
            // update_agencias_old_name
            // 
            update_agencias_old_name.Location = new Point(556, 105);
            update_agencias_old_name.Name = "update_agencias_old_name";
            update_agencias_old_name.Size = new Size(276, 34);
            update_agencias_old_name.TabIndex = 17;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(239, 108);
            label15.Name = "label15";
            label15.Size = new Size(276, 28);
            label15.TabIndex = 16;
            label15.Text = "Antiguo nombre de la agencia";
            // 
            // tabUpdateClientes
            // 
            tabUpdateClientes.Controls.Add(update_client_new_dni_avalador);
            tabUpdateClientes.Controls.Add(label43);
            tabUpdateClientes.Controls.Add(update_client_new_phone);
            tabUpdateClientes.Controls.Add(label44);
            tabUpdateClientes.Controls.Add(update_client_new_address);
            tabUpdateClientes.Controls.Add(label45);
            tabUpdateClientes.Controls.Add(update_client_dni);
            tabUpdateClientes.Controls.Add(label46);
            tabUpdateClientes.Controls.Add(button_update_client);
            tabUpdateClientes.Controls.Add(label47);
            tabUpdateClientes.Controls.Add(update_client_new_name);
            tabUpdateClientes.Controls.Add(label48);
            tabUpdateClientes.Location = new Point(4, 29);
            tabUpdateClientes.Name = "tabUpdateClientes";
            tabUpdateClientes.Padding = new Padding(3);
            tabUpdateClientes.Size = new Size(1134, 467);
            tabUpdateClientes.TabIndex = 1;
            tabUpdateClientes.Text = "Clientes";
            tabUpdateClientes.UseVisualStyleBackColor = true;
            // 
            // update_client_new_dni_avalador
            // 
            update_client_new_dni_avalador.Location = new Point(530, 297);
            update_client_new_dni_avalador.Name = "update_client_new_dni_avalador";
            update_client_new_dni_avalador.Size = new Size(276, 34);
            update_client_new_dni_avalador.TabIndex = 63;
            // 
            // label43
            // 
            label43.AutoSize = true;
            label43.Location = new Point(309, 297);
            label43.Name = "label43";
            label43.Size = new Size(193, 28);
            label43.TabIndex = 62;
            label43.Text = "Nuevo DNI Avalador";
            // 
            // update_client_new_phone
            // 
            update_client_new_phone.Location = new Point(530, 245);
            update_client_new_phone.Name = "update_client_new_phone";
            update_client_new_phone.Size = new Size(276, 34);
            update_client_new_phone.TabIndex = 61;
            // 
            // label44
            // 
            label44.AutoSize = true;
            label44.Location = new Point(354, 251);
            label44.Name = "label44";
            label44.Size = new Size(148, 28);
            label44.TabIndex = 60;
            label44.Text = "Nuevo telefono";
            // 
            // update_client_new_address
            // 
            update_client_new_address.Location = new Point(530, 205);
            update_client_new_address.Name = "update_client_new_address";
            update_client_new_address.Size = new Size(276, 34);
            update_client_new_address.TabIndex = 59;
            // 
            // label45
            // 
            label45.AutoSize = true;
            label45.Location = new Point(349, 205);
            label45.Name = "label45";
            label45.Size = new Size(153, 28);
            label45.TabIndex = 58;
            label45.Text = "Nueva dirección";
            // 
            // update_client_dni
            // 
            update_client_dni.Location = new Point(530, 104);
            update_client_dni.Name = "update_client_dni";
            update_client_dni.Size = new Size(276, 34);
            update_client_dni.TabIndex = 57;
            // 
            // label46
            // 
            label46.AutoSize = true;
            label46.Location = new Point(456, 104);
            label46.Name = "label46";
            label46.Size = new Size(46, 28);
            label46.TabIndex = 56;
            label46.Text = "DNI";
            // 
            // button_update_client
            // 
            button_update_client.Location = new Point(456, 388);
            button_update_client.Name = "button_update_client";
            button_update_client.Size = new Size(172, 42);
            button_update_client.TabIndex = 55;
            button_update_client.Text = "Actualizar Cliente";
            button_update_client.UseVisualStyleBackColor = true;
            button_update_client.Click += button_update_client_Click;
            // 
            // label47
            // 
            label47.AutoSize = true;
            label47.Location = new Point(492, 55);
            label47.Name = "label47";
            label47.Size = new Size(80, 28);
            label47.TabIndex = 54;
            label47.Text = "Clientes";
            // 
            // update_client_new_name
            // 
            update_client_new_name.Location = new Point(530, 165);
            update_client_new_name.Name = "update_client_new_name";
            update_client_new_name.Size = new Size(276, 34);
            update_client_new_name.TabIndex = 53;
            // 
            // label48
            // 
            label48.AutoSize = true;
            label48.Location = new Point(269, 165);
            label48.Name = "label48";
            label48.Size = new Size(233, 28);
            label48.TabIndex = 52;
            label48.Text = "Nuevo nombre completo";
            // 
            // tabUpdateCoches
            // 
            tabUpdateCoches.Controls.Add(update_car_id);
            tabUpdateCoches.Controls.Add(label55);
            tabUpdateCoches.Controls.Add(update_car_new_marca);
            tabUpdateCoches.Controls.Add(label49);
            tabUpdateCoches.Controls.Add(update_car_new_color);
            tabUpdateCoches.Controls.Add(label50);
            tabUpdateCoches.Controls.Add(update_car_new_model);
            tabUpdateCoches.Controls.Add(label51);
            tabUpdateCoches.Controls.Add(update_car_new_matricula);
            tabUpdateCoches.Controls.Add(label52);
            tabUpdateCoches.Controls.Add(button_update_car);
            tabUpdateCoches.Controls.Add(label53);
            tabUpdateCoches.Controls.Add(update_car_new_garage);
            tabUpdateCoches.Controls.Add(label54);
            tabUpdateCoches.Location = new Point(4, 29);
            tabUpdateCoches.Name = "tabUpdateCoches";
            tabUpdateCoches.Size = new Size(1134, 467);
            tabUpdateCoches.TabIndex = 2;
            tabUpdateCoches.Text = "Coches";
            tabUpdateCoches.UseVisualStyleBackColor = true;
            // 
            // update_car_id
            // 
            update_car_id.Location = new Point(551, 103);
            update_car_id.Name = "update_car_id";
            update_car_id.Size = new Size(59, 34);
            update_car_id.TabIndex = 53;
            // 
            // label55
            // 
            label55.AutoSize = true;
            label55.Location = new Point(422, 109);
            label55.Name = "label55";
            label55.Size = new Size(88, 28);
            label55.TabIndex = 52;
            label55.Text = "Id Coche";
            // 
            // update_car_new_marca
            // 
            update_car_new_marca.Location = new Point(551, 330);
            update_car_new_marca.Name = "update_car_new_marca";
            update_car_new_marca.Size = new Size(276, 34);
            update_car_new_marca.TabIndex = 51;
            // 
            // label49
            // 
            label49.AutoSize = true;
            label49.Location = new Point(384, 333);
            label49.Name = "label49";
            label49.Size = new Size(126, 28);
            label49.TabIndex = 50;
            label49.Text = "Nueva marca";
            // 
            // update_car_new_color
            // 
            update_car_new_color.Location = new Point(551, 290);
            update_car_new_color.Name = "update_car_new_color";
            update_car_new_color.Size = new Size(276, 34);
            update_car_new_color.TabIndex = 49;
            // 
            // label50
            // 
            label50.AutoSize = true;
            label50.Location = new Point(390, 293);
            label50.Name = "label50";
            label50.Size = new Size(120, 28);
            label50.TabIndex = 48;
            label50.Text = "Nuevo color";
            // 
            // update_car_new_model
            // 
            update_car_new_model.Location = new Point(551, 250);
            update_car_new_model.Name = "update_car_new_model";
            update_car_new_model.Size = new Size(276, 34);
            update_car_new_model.TabIndex = 47;
            // 
            // label51
            // 
            label51.AutoSize = true;
            label51.Location = new Point(367, 253);
            label51.Name = "label51";
            label51.Size = new Size(143, 28);
            label51.TabIndex = 46;
            label51.Text = "Nuevo modelo";
            // 
            // update_car_new_matricula
            // 
            update_car_new_matricula.Location = new Point(551, 170);
            update_car_new_matricula.Name = "update_car_new_matricula";
            update_car_new_matricula.Size = new Size(276, 34);
            update_car_new_matricula.TabIndex = 45;
            // 
            // label52
            // 
            label52.AutoSize = true;
            label52.Location = new Point(356, 176);
            label52.Name = "label52";
            label52.Size = new Size(154, 28);
            label52.TabIndex = 44;
            label52.Text = "Nueva matrícula";
            // 
            // button_update_car
            // 
            button_update_car.Location = new Point(468, 399);
            button_update_car.Name = "button_update_car";
            button_update_car.Size = new Size(185, 42);
            button_update_car.TabIndex = 43;
            button_update_car.Text = "Actualizar Vehículo";
            button_update_car.UseVisualStyleBackColor = true;
            button_update_car.Click += button_update_car_Click;
            // 
            // label53
            // 
            label53.AutoSize = true;
            label53.Location = new Point(511, 57);
            label53.Name = "label53";
            label53.Size = new Size(74, 28);
            label53.TabIndex = 42;
            label53.Text = "Coches";
            // 
            // update_car_new_garage
            // 
            update_car_new_garage.Location = new Point(551, 210);
            update_car_new_garage.Name = "update_car_new_garage";
            update_car_new_garage.Size = new Size(276, 34);
            update_car_new_garage.TabIndex = 41;
            // 
            // label54
            // 
            label54.AutoSize = true;
            label54.Location = new Point(379, 213);
            label54.Name = "label54";
            label54.Size = new Size(131, 28);
            label54.TabIndex = 40;
            label54.Text = "Nuevo Garaje";
            // 
            // tabUpdateReservas
            // 
            tabUpdateReservas.Controls.Add(label68);
            tabUpdateReservas.Controls.Add(label64);
            tabUpdateReservas.Controls.Add(label63);
            tabUpdateReservas.Controls.Add(update_reservas_id);
            tabUpdateReservas.Controls.Add(label62);
            tabUpdateReservas.Controls.Add(update_reservas_new_agencia_name);
            tabUpdateReservas.Controls.Add(label56);
            tabUpdateReservas.Controls.Add(update_reservas_new_cost);
            tabUpdateReservas.Controls.Add(label57);
            tabUpdateReservas.Controls.Add(update_reservas_new_end_date);
            tabUpdateReservas.Controls.Add(label58);
            tabUpdateReservas.Controls.Add(update_reservas_new_dni_client);
            tabUpdateReservas.Controls.Add(label59);
            tabUpdateReservas.Controls.Add(button_update_reservas);
            tabUpdateReservas.Controls.Add(label60);
            tabUpdateReservas.Controls.Add(update_reservas_new_begin_date);
            tabUpdateReservas.Controls.Add(label61);
            tabUpdateReservas.Location = new Point(4, 29);
            tabUpdateReservas.Name = "tabUpdateReservas";
            tabUpdateReservas.Size = new Size(1134, 467);
            tabUpdateReservas.TabIndex = 3;
            tabUpdateReservas.Text = "Reservas";
            tabUpdateReservas.UseVisualStyleBackColor = true;
            // 
            // label68
            // 
            label68.AutoSize = true;
            label68.Location = new Point(508, 269);
            label68.Name = "label68";
            label68.Size = new Size(23, 28);
            label68.TabIndex = 68;
            label68.Text = "$";
            // 
            // label64
            // 
            label64.AutoSize = true;
            label64.Location = new Point(811, 232);
            label64.Name = "label64";
            label64.Size = new Size(196, 28);
            label64.TabIndex = 67;
            label64.Text = "yy/mm/dd  hh:mm:ss";
            // 
            // label63
            // 
            label63.AutoSize = true;
            label63.Location = new Point(811, 189);
            label63.Name = "label63";
            label63.Size = new Size(196, 28);
            label63.TabIndex = 66;
            label63.Text = "yy/mm/dd  hh:mm:ss";
            // 
            // update_reservas_id
            // 
            update_reservas_id.Location = new Point(529, 90);
            update_reservas_id.Name = "update_reservas_id";
            update_reservas_id.Size = new Size(74, 34);
            update_reservas_id.TabIndex = 65;
            // 
            // label62
            // 
            label62.AutoSize = true;
            label62.Location = new Point(404, 96);
            label62.Name = "label62";
            label62.Size = new Size(98, 28);
            label62.TabIndex = 64;
            label62.Text = "ID reserva";
            // 
            // update_reservas_new_agencia_name
            // 
            update_reservas_new_agencia_name.Location = new Point(529, 306);
            update_reservas_new_agencia_name.Name = "update_reservas_new_agencia_name";
            update_reservas_new_agencia_name.Size = new Size(276, 34);
            update_reservas_new_agencia_name.TabIndex = 63;
            // 
            // label56
            // 
            label56.AutoSize = true;
            label56.Location = new Point(318, 309);
            label56.Name = "label56";
            label56.Size = new Size(184, 28);
            label56.TabIndex = 62;
            label56.Text = "Nombre de agencia";
            // 
            // update_reservas_new_cost
            // 
            update_reservas_new_cost.Location = new Point(529, 266);
            update_reservas_new_cost.Name = "update_reservas_new_cost";
            update_reservas_new_cost.Size = new Size(276, 34);
            update_reservas_new_cost.TabIndex = 61;
            // 
            // label57
            // 
            label57.AutoSize = true;
            label57.Location = new Point(393, 266);
            label57.Name = "label57";
            label57.Size = new Size(109, 28);
            label57.TabIndex = 60;
            label57.Text = "Costo total";
            // 
            // update_reservas_new_end_date
            // 
            update_reservas_new_end_date.Location = new Point(529, 226);
            update_reservas_new_end_date.Name = "update_reservas_new_end_date";
            update_reservas_new_end_date.Size = new Size(276, 34);
            update_reservas_new_end_date.TabIndex = 59;
            // 
            // label58
            // 
            label58.AutoSize = true;
            label58.Location = new Point(398, 226);
            label58.Name = "label58";
            label58.Size = new Size(104, 28);
            label58.TabIndex = 58;
            label58.Text = "Fecha final";
            // 
            // update_reservas_new_dni_client
            // 
            update_reservas_new_dni_client.Location = new Point(529, 146);
            update_reservas_new_dni_client.Name = "update_reservas_new_dni_client";
            update_reservas_new_dni_client.Size = new Size(276, 34);
            update_reservas_new_dni_client.TabIndex = 57;
            // 
            // label59
            // 
            label59.AutoSize = true;
            label59.Location = new Point(394, 152);
            label59.Name = "label59";
            label59.Size = new Size(108, 28);
            label59.TabIndex = 56;
            label59.Text = "DNI cliente";
            // 
            // button_update_reservas
            // 
            button_update_reservas.Location = new Point(453, 375);
            button_update_reservas.Name = "button_update_reservas";
            button_update_reservas.Size = new Size(179, 42);
            button_update_reservas.TabIndex = 55;
            button_update_reservas.Text = "Actualizar Reserva";
            button_update_reservas.UseVisualStyleBackColor = true;
            button_update_reservas.Click += button_update_reservas_Click;
            // 
            // label60
            // 
            label60.AutoSize = true;
            label60.Location = new Point(490, 50);
            label60.Name = "label60";
            label60.Size = new Size(86, 28);
            label60.TabIndex = 54;
            label60.Text = "Reservas";
            // 
            // update_reservas_new_begin_date
            // 
            update_reservas_new_begin_date.Location = new Point(529, 186);
            update_reservas_new_begin_date.Name = "update_reservas_new_begin_date";
            update_reservas_new_begin_date.Size = new Size(276, 34);
            update_reservas_new_begin_date.TabIndex = 53;
            // 
            // label61
            // 
            label61.AutoSize = true;
            label61.Location = new Point(388, 189);
            label61.Name = "label61";
            label61.Size = new Size(114, 28);
            label61.TabIndex = 52;
            label61.Text = "Fecha inicio";
            // 
            // tabPage3
            // 
            tabPage3.Controls.Add(label4);
            tabPage3.Controls.Add(tabControl2);
            tabPage3.Location = new Point(4, 37);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(1196, 588);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "Insertar datos";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(497, 22);
            label4.Name = "label4";
            label4.Size = new Size(133, 28);
            label4.TabIndex = 2;
            label4.Text = "Insertar Datos";
            // 
            // tabControl2
            // 
            tabControl2.Controls.Add(tabPage5);
            tabControl2.Controls.Add(tabPage6);
            tabControl2.Controls.Add(tabPage7);
            tabControl2.Controls.Add(tabPage8);
            tabControl2.Location = new Point(27, 83);
            tabControl2.Name = "tabControl2";
            tabControl2.SelectedIndex = 0;
            tabControl2.Size = new Size(1142, 461);
            tabControl2.TabIndex = 1;
            // 
            // tabPage5
            // 
            tabPage5.Controls.Add(insert_agencia_address);
            tabPage5.Controls.Add(label17);
            tabPage5.Controls.Add(insert_agencia);
            tabPage5.Controls.Add(label18);
            tabPage5.Controls.Add(insert_agencia_name);
            tabPage5.Controls.Add(label19);
            tabPage5.Location = new Point(4, 37);
            tabPage5.Name = "tabPage5";
            tabPage5.Padding = new Padding(3);
            tabPage5.Size = new Size(1134, 420);
            tabPage5.TabIndex = 0;
            tabPage5.Text = "Agencias";
            tabPage5.UseVisualStyleBackColor = true;
            // 
            // insert_agencia_address
            // 
            insert_agencia_address.Location = new Point(550, 171);
            insert_agencia_address.Name = "insert_agencia_address";
            insert_agencia_address.Size = new Size(276, 34);
            insert_agencia_address.TabIndex = 27;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(415, 177);
            label17.Name = "label17";
            label17.Size = new Size(94, 28);
            label17.TabIndex = 26;
            label17.Text = "Dirección";
            // 
            // insert_agencia
            // 
            insert_agencia.Location = new Point(471, 314);
            insert_agencia.Name = "insert_agencia";
            insert_agencia.Size = new Size(166, 42);
            insert_agencia.TabIndex = 25;
            insert_agencia.Text = "Crear Agencia";
            insert_agencia.UseVisualStyleBackColor = true;
            insert_agencia.Click += insert_agencia_Click;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(512, 46);
            label18.Name = "label18";
            label18.Size = new Size(90, 28);
            label18.TabIndex = 24;
            label18.Text = "Agencias";
            // 
            // insert_agencia_name
            // 
            insert_agencia_name.Location = new Point(550, 107);
            insert_agencia_name.Name = "insert_agencia_name";
            insert_agencia_name.Size = new Size(276, 34);
            insert_agencia_name.TabIndex = 23;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(305, 107);
            label19.Name = "label19";
            label19.Size = new Size(204, 28);
            label19.TabIndex = 22;
            label19.Text = "Nombre de la agencia";
            // 
            // tabPage6
            // 
            tabPage6.Controls.Add(insert_cliente_avalador);
            tabPage6.Controls.Add(label25);
            tabPage6.Controls.Add(insert_cliente_phone);
            tabPage6.Controls.Add(label26);
            tabPage6.Controls.Add(insert_cliente_address);
            tabPage6.Controls.Add(label27);
            tabPage6.Controls.Add(insert_cliente_dni);
            tabPage6.Controls.Add(label28);
            tabPage6.Controls.Add(button_insert_cliente);
            tabPage6.Controls.Add(label29);
            tabPage6.Controls.Add(insert_cliente_name);
            tabPage6.Controls.Add(label30);
            tabPage6.Location = new Point(4, 29);
            tabPage6.Name = "tabPage6";
            tabPage6.Padding = new Padding(3);
            tabPage6.Size = new Size(1134, 428);
            tabPage6.TabIndex = 1;
            tabPage6.Text = "Clientes";
            tabPage6.UseVisualStyleBackColor = true;
            // 
            // insert_cliente_avalador
            // 
            insert_cliente_avalador.Location = new Point(497, 271);
            insert_cliente_avalador.Name = "insert_cliente_avalador";
            insert_cliente_avalador.Size = new Size(276, 34);
            insert_cliente_avalador.TabIndex = 51;
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Location = new Point(339, 271);
            label25.Name = "label25";
            label25.Size = new Size(130, 28);
            label25.TabIndex = 50;
            label25.Text = "DNI Avalador";
            // 
            // insert_cliente_phone
            // 
            insert_cliente_phone.Location = new Point(497, 219);
            insert_cliente_phone.Name = "insert_cliente_phone";
            insert_cliente_phone.Size = new Size(276, 34);
            insert_cliente_phone.TabIndex = 49;
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Location = new Point(384, 219);
            label26.Name = "label26";
            label26.Size = new Size(85, 28);
            label26.TabIndex = 48;
            label26.Text = "telefono";
            // 
            // insert_cliente_address
            // 
            insert_cliente_address.Location = new Point(497, 179);
            insert_cliente_address.Name = "insert_cliente_address";
            insert_cliente_address.Size = new Size(276, 34);
            insert_cliente_address.TabIndex = 47;
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Location = new Point(377, 179);
            label27.Name = "label27";
            label27.Size = new Size(92, 28);
            label27.TabIndex = 46;
            label27.Text = "dirección";
            // 
            // insert_cliente_dni
            // 
            insert_cliente_dni.Location = new Point(497, 99);
            insert_cliente_dni.Name = "insert_cliente_dni";
            insert_cliente_dni.Size = new Size(276, 34);
            insert_cliente_dni.TabIndex = 45;
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.Location = new Point(423, 99);
            label28.Name = "label28";
            label28.Size = new Size(46, 28);
            label28.TabIndex = 44;
            label28.Text = "DNI";
            // 
            // button_insert_cliente
            // 
            button_insert_cliente.Location = new Point(418, 357);
            button_insert_cliente.Name = "button_insert_cliente";
            button_insert_cliente.Size = new Size(172, 42);
            button_insert_cliente.TabIndex = 43;
            button_insert_cliente.Text = "Guardar Cliente";
            button_insert_cliente.UseVisualStyleBackColor = true;
            button_insert_cliente.Click += button_insert_cliente_Click;
            // 
            // label29
            // 
            label29.AutoSize = true;
            label29.Location = new Point(459, 50);
            label29.Name = "label29";
            label29.Size = new Size(80, 28);
            label29.TabIndex = 42;
            label29.Text = "Clientes";
            // 
            // insert_cliente_name
            // 
            insert_cliente_name.Location = new Point(497, 139);
            insert_cliente_name.Name = "insert_cliente_name";
            insert_cliente_name.Size = new Size(276, 34);
            insert_cliente_name.TabIndex = 41;
            // 
            // label30
            // 
            label30.AutoSize = true;
            label30.Location = new Point(295, 139);
            label30.Name = "label30";
            label30.Size = new Size(174, 28);
            label30.TabIndex = 40;
            label30.Text = "Nombre completo";
            // 
            // tabPage7
            // 
            tabPage7.Controls.Add(insert_coches_marca);
            tabPage7.Controls.Add(label24);
            tabPage7.Controls.Add(insert_coches_color);
            tabPage7.Controls.Add(label23);
            tabPage7.Controls.Add(insert_coches_modelo);
            tabPage7.Controls.Add(label22);
            tabPage7.Controls.Add(insert_coches_matricula);
            tabPage7.Controls.Add(label16);
            tabPage7.Controls.Add(button2);
            tabPage7.Controls.Add(label20);
            tabPage7.Controls.Add(insert_coches_garaje);
            tabPage7.Controls.Add(label21);
            tabPage7.Location = new Point(4, 29);
            tabPage7.Name = "tabPage7";
            tabPage7.Size = new Size(1134, 428);
            tabPage7.TabIndex = 2;
            tabPage7.Text = "Coches";
            tabPage7.UseVisualStyleBackColor = true;
            // 
            // insert_coches_marca
            // 
            insert_coches_marca.Location = new Point(550, 279);
            insert_coches_marca.Name = "insert_coches_marca";
            insert_coches_marca.Size = new Size(276, 34);
            insert_coches_marca.TabIndex = 39;
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Location = new Point(443, 279);
            label24.Name = "label24";
            label24.Size = new Size(66, 28);
            label24.TabIndex = 38;
            label24.Text = "Marca";
            // 
            // insert_coches_color
            // 
            insert_coches_color.Location = new Point(550, 239);
            insert_coches_color.Name = "insert_coches_color";
            insert_coches_color.Size = new Size(276, 34);
            insert_coches_color.TabIndex = 37;
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Location = new Point(449, 239);
            label23.Name = "label23";
            label23.Size = new Size(60, 28);
            label23.TabIndex = 36;
            label23.Text = "Color";
            // 
            // insert_coches_modelo
            // 
            insert_coches_modelo.Location = new Point(550, 199);
            insert_coches_modelo.Name = "insert_coches_modelo";
            insert_coches_modelo.Size = new Size(276, 34);
            insert_coches_modelo.TabIndex = 35;
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new Point(428, 199);
            label22.Name = "label22";
            label22.Size = new Size(81, 28);
            label22.TabIndex = 34;
            label22.Text = "Modelo";
            // 
            // insert_coches_matricula
            // 
            insert_coches_matricula.Location = new Point(550, 119);
            insert_coches_matricula.Name = "insert_coches_matricula";
            insert_coches_matricula.Size = new Size(276, 34);
            insert_coches_matricula.TabIndex = 33;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(415, 125);
            label16.Name = "label16";
            label16.Size = new Size(94, 28);
            label16.TabIndex = 32;
            label16.Text = "Matrícula";
            // 
            // button2
            // 
            button2.Location = new Point(466, 361);
            button2.Name = "button2";
            button2.Size = new Size(172, 42);
            button2.TabIndex = 31;
            button2.Text = "Guardar Vehículo";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click_1;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(514, 55);
            label20.Name = "label20";
            label20.Size = new Size(74, 28);
            label20.TabIndex = 30;
            label20.Text = "Coches";
            // 
            // insert_coches_garaje
            // 
            insert_coches_garaje.Location = new Point(550, 159);
            insert_coches_garaje.Name = "insert_coches_garaje";
            insert_coches_garaje.Size = new Size(276, 34);
            insert_coches_garaje.TabIndex = 29;
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(441, 159);
            label21.Name = "label21";
            label21.Size = new Size(68, 28);
            label21.TabIndex = 28;
            label21.Text = "Garaje";
            // 
            // tabPage8
            // 
            tabPage8.Controls.Add(label69);
            tabPage8.Controls.Add(label66);
            tabPage8.Controls.Add(label65);
            tabPage8.Controls.Add(insert_reserva_agencia_name);
            tabPage8.Controls.Add(label31);
            tabPage8.Controls.Add(insert_reserva_costo);
            tabPage8.Controls.Add(label32);
            tabPage8.Controls.Add(insert_reserva_final_date);
            tabPage8.Controls.Add(label33);
            tabPage8.Controls.Add(insert_reserva_dni_client);
            tabPage8.Controls.Add(label34);
            tabPage8.Controls.Add(button_insert_reserva);
            tabPage8.Controls.Add(label35);
            tabPage8.Controls.Add(insert_reserva_begin_date);
            tabPage8.Controls.Add(label36);
            tabPage8.Location = new Point(4, 29);
            tabPage8.Name = "tabPage8";
            tabPage8.Size = new Size(1134, 428);
            tabPage8.TabIndex = 3;
            tabPage8.Text = "Reservas";
            tabPage8.UseVisualStyleBackColor = true;
            // 
            // label69
            // 
            label69.AutoSize = true;
            label69.Location = new Point(476, 222);
            label69.Name = "label69";
            label69.Size = new Size(23, 28);
            label69.TabIndex = 69;
            label69.Text = "$";
            // 
            // label66
            // 
            label66.AutoSize = true;
            label66.Location = new Point(792, 185);
            label66.Name = "label66";
            label66.Size = new Size(196, 28);
            label66.TabIndex = 68;
            label66.Text = "yy/mm/dd  hh:mm:ss";
            // 
            // label65
            // 
            label65.AutoSize = true;
            label65.Location = new Point(792, 145);
            label65.Name = "label65";
            label65.Size = new Size(196, 28);
            label65.TabIndex = 67;
            label65.Text = "yy/mm/dd  hh:mm:ss";
            // 
            // insert_reserva_agencia_name
            // 
            insert_reserva_agencia_name.Location = new Point(497, 259);
            insert_reserva_agencia_name.Name = "insert_reserva_agencia_name";
            insert_reserva_agencia_name.Size = new Size(276, 34);
            insert_reserva_agencia_name.TabIndex = 51;
            // 
            // label31
            // 
            label31.AutoSize = true;
            label31.Location = new Point(286, 262);
            label31.Name = "label31";
            label31.Size = new Size(184, 28);
            label31.TabIndex = 50;
            label31.Text = "Nombre de agencia";
            // 
            // insert_reserva_costo
            // 
            insert_reserva_costo.Location = new Point(497, 219);
            insert_reserva_costo.Name = "insert_reserva_costo";
            insert_reserva_costo.Size = new Size(276, 34);
            insert_reserva_costo.TabIndex = 49;
            // 
            // label32
            // 
            label32.AutoSize = true;
            label32.Location = new Point(361, 219);
            label32.Name = "label32";
            label32.Size = new Size(109, 28);
            label32.TabIndex = 48;
            label32.Text = "Costo total";
            // 
            // insert_reserva_final_date
            // 
            insert_reserva_final_date.Location = new Point(497, 179);
            insert_reserva_final_date.Name = "insert_reserva_final_date";
            insert_reserva_final_date.Size = new Size(276, 34);
            insert_reserva_final_date.TabIndex = 47;
            // 
            // label33
            // 
            label33.AutoSize = true;
            label33.Location = new Point(366, 179);
            label33.Name = "label33";
            label33.Size = new Size(104, 28);
            label33.TabIndex = 46;
            label33.Text = "Fecha final";
            // 
            // insert_reserva_dni_client
            // 
            insert_reserva_dni_client.Location = new Point(497, 99);
            insert_reserva_dni_client.Name = "insert_reserva_dni_client";
            insert_reserva_dni_client.Size = new Size(276, 34);
            insert_reserva_dni_client.TabIndex = 45;
            // 
            // label34
            // 
            label34.AutoSize = true;
            label34.Location = new Point(362, 105);
            label34.Name = "label34";
            label34.Size = new Size(108, 28);
            label34.TabIndex = 44;
            label34.Text = "DNI cliente";
            // 
            // button_insert_reserva
            // 
            button_insert_reserva.Location = new Point(414, 328);
            button_insert_reserva.Name = "button_insert_reserva";
            button_insert_reserva.Size = new Size(172, 42);
            button_insert_reserva.TabIndex = 43;
            button_insert_reserva.Text = "Crear Reserva";
            button_insert_reserva.UseVisualStyleBackColor = true;
            button_insert_reserva.Click += button_insert_reserva_Click;
            // 
            // label35
            // 
            label35.AutoSize = true;
            label35.Location = new Point(459, 50);
            label35.Name = "label35";
            label35.Size = new Size(86, 28);
            label35.TabIndex = 42;
            label35.Text = "Reservas";
            // 
            // insert_reserva_begin_date
            // 
            insert_reserva_begin_date.Location = new Point(497, 139);
            insert_reserva_begin_date.Name = "insert_reserva_begin_date";
            insert_reserva_begin_date.Size = new Size(276, 34);
            insert_reserva_begin_date.TabIndex = 41;
            // 
            // label36
            // 
            label36.AutoSize = true;
            label36.Location = new Point(356, 142);
            label36.Name = "label36";
            label36.Size = new Size(114, 28);
            label36.TabIndex = 40;
            label36.Text = "Fecha inicio";
            // 
            // tabPage4
            // 
            tabPage4.Controls.Add(label5);
            tabPage4.Controls.Add(tabControl3);
            tabPage4.Location = new Point(4, 37);
            tabPage4.Name = "tabPage4";
            tabPage4.Size = new Size(1196, 588);
            tabPage4.TabIndex = 3;
            tabPage4.Text = "Eliminar datos";
            tabPage4.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(497, 22);
            label5.Name = "label5";
            label5.Size = new Size(138, 28);
            label5.TabIndex = 2;
            label5.Text = "Eliminar Datos";
            // 
            // tabControl3
            // 
            tabControl3.Controls.Add(tabPage9);
            tabControl3.Controls.Add(tabPage10);
            tabControl3.Controls.Add(tabPage11);
            tabControl3.Controls.Add(tabPage12);
            tabControl3.Location = new Point(27, 83);
            tabControl3.Name = "tabControl3";
            tabControl3.SelectedIndex = 0;
            tabControl3.Size = new Size(1142, 480);
            tabControl3.TabIndex = 1;
            // 
            // tabPage9
            // 
            tabPage9.Controls.Add(button_delete_agencia);
            tabPage9.Controls.Add(label9);
            tabPage9.Controls.Add(delete_agencia_name);
            tabPage9.Controls.Add(label10);
            tabPage9.Controls.Add(label11);
            tabPage9.Location = new Point(4, 37);
            tabPage9.Name = "tabPage9";
            tabPage9.Padding = new Padding(3);
            tabPage9.Size = new Size(1134, 439);
            tabPage9.TabIndex = 0;
            tabPage9.Text = "Agencias";
            tabPage9.UseVisualStyleBackColor = true;
            // 
            // button_delete_agencia
            // 
            button_delete_agencia.Location = new Point(474, 332);
            button_delete_agencia.Name = "button_delete_agencia";
            button_delete_agencia.Size = new Size(166, 42);
            button_delete_agencia.TabIndex = 15;
            button_delete_agencia.Text = "Eliminar agencia";
            button_delete_agencia.UseVisualStyleBackColor = true;
            button_delete_agencia.Click += button_delete_agencia_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(515, 64);
            label9.Name = "label9";
            label9.Size = new Size(90, 28);
            label9.TabIndex = 14;
            label9.Text = "Agencias";
            // 
            // delete_agencia_name
            // 
            delete_agencia_name.Location = new Point(550, 159);
            delete_agencia_name.Name = "delete_agencia_name";
            delete_agencia_name.Size = new Size(276, 34);
            delete_agencia_name.TabIndex = 13;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(305, 159);
            label10.Name = "label10";
            label10.Size = new Size(204, 28);
            label10.TabIndex = 11;
            label10.Text = "Nombre de la agencia";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(444, 159);
            label11.Name = "label11";
            label11.Size = new Size(0, 28);
            label11.TabIndex = 10;
            // 
            // tabPage10
            // 
            tabPage10.Controls.Add(delete_clientes);
            tabPage10.Controls.Add(label8);
            tabPage10.Controls.Add(delete_name_cliente);
            tabPage10.Controls.Add(delete_dni_cliente);
            tabPage10.Controls.Add(label7);
            tabPage10.Controls.Add(label6);
            tabPage10.Location = new Point(4, 29);
            tabPage10.Name = "tabPage10";
            tabPage10.Padding = new Padding(3);
            tabPage10.Size = new Size(1134, 447);
            tabPage10.TabIndex = 1;
            tabPage10.Text = "Clientes";
            tabPage10.UseVisualStyleBackColor = true;
            // 
            // delete_clientes
            // 
            delete_clientes.Location = new Point(466, 310);
            delete_clientes.Name = "delete_clientes";
            delete_clientes.Size = new Size(166, 42);
            delete_clientes.TabIndex = 9;
            delete_clientes.Text = "Eliminar cliente";
            delete_clientes.UseVisualStyleBackColor = true;
            delete_clientes.Click += delete_clientes_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(507, 42);
            label8.Name = "label8";
            label8.Size = new Size(80, 28);
            label8.TabIndex = 8;
            label8.Text = "Clientes";
            // 
            // delete_name_cliente
            // 
            delete_name_cliente.Location = new Point(540, 195);
            delete_name_cliente.Name = "delete_name_cliente";
            delete_name_cliente.Size = new Size(276, 34);
            delete_name_cliente.TabIndex = 7;
            // 
            // delete_dni_cliente
            // 
            delete_dni_cliente.Location = new Point(540, 137);
            delete_dni_cliente.Name = "delete_dni_cliente";
            delete_dni_cliente.Size = new Size(183, 34);
            delete_dni_cliente.TabIndex = 6;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(303, 195);
            label7.Name = "label7";
            label7.Size = new Size(177, 28);
            label7.TabIndex = 5;
            label7.Text = "Nombre Completo";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(436, 137);
            label6.Name = "label6";
            label6.Size = new Size(46, 28);
            label6.TabIndex = 4;
            label6.Text = "DNI";
            // 
            // tabPage11
            // 
            tabPage11.Controls.Add(button_delete_coche);
            tabPage11.Controls.Add(label12);
            tabPage11.Controls.Add(delete_coche_matricula);
            tabPage11.Controls.Add(label13);
            tabPage11.Location = new Point(4, 37);
            tabPage11.Name = "tabPage11";
            tabPage11.Size = new Size(1134, 439);
            tabPage11.TabIndex = 2;
            tabPage11.Text = "Coches";
            tabPage11.UseVisualStyleBackColor = true;
            // 
            // button_delete_coche
            // 
            button_delete_coche.Location = new Point(476, 332);
            button_delete_coche.Name = "button_delete_coche";
            button_delete_coche.Size = new Size(166, 42);
            button_delete_coche.TabIndex = 19;
            button_delete_coche.Text = "Eliminar coche";
            button_delete_coche.UseVisualStyleBackColor = true;
            button_delete_coche.Click += button_delete_coche_Click_1;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(517, 64);
            label12.Name = "label12";
            label12.Size = new Size(74, 28);
            label12.TabIndex = 18;
            label12.Text = "Coches";
            // 
            // delete_coche_matricula
            // 
            delete_coche_matricula.Location = new Point(552, 159);
            delete_coche_matricula.Name = "delete_coche_matricula";
            delete_coche_matricula.Size = new Size(276, 34);
            delete_coche_matricula.TabIndex = 17;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(307, 159);
            label13.Name = "label13";
            label13.Size = new Size(182, 28);
            label13.TabIndex = 16;
            label13.Text = "Matrícula del coche";
            // 
            // tabPage12
            // 
            tabPage12.Controls.Add(label67);
            tabPage12.Controls.Add(delete_reserva_agencia_name);
            tabPage12.Controls.Add(label37);
            tabPage12.Controls.Add(delete_reserva_dni_cliente);
            tabPage12.Controls.Add(label38);
            tabPage12.Controls.Add(button3);
            tabPage12.Controls.Add(label39);
            tabPage12.Controls.Add(delete_reserva_begin_date);
            tabPage12.Controls.Add(label40);
            tabPage12.Location = new Point(4, 29);
            tabPage12.Name = "tabPage12";
            tabPage12.Size = new Size(1134, 447);
            tabPage12.TabIndex = 3;
            tabPage12.Text = "Reservas";
            tabPage12.UseVisualStyleBackColor = true;
            // 
            // label67
            // 
            label67.AutoSize = true;
            label67.Location = new Point(827, 154);
            label67.Name = "label67";
            label67.Size = new Size(196, 28);
            label67.TabIndex = 67;
            label67.Text = "yy/mm/dd  hh:mm:ss";
            // 
            // delete_reserva_agencia_name
            // 
            delete_reserva_agencia_name.Location = new Point(535, 188);
            delete_reserva_agencia_name.Name = "delete_reserva_agencia_name";
            delete_reserva_agencia_name.Size = new Size(276, 34);
            delete_reserva_agencia_name.TabIndex = 59;
            // 
            // label37
            // 
            label37.AutoSize = true;
            label37.Location = new Point(324, 191);
            label37.Name = "label37";
            label37.Size = new Size(184, 28);
            label37.TabIndex = 58;
            label37.Text = "Nombre de agencia";
            // 
            // delete_reserva_dni_cliente
            // 
            delete_reserva_dni_cliente.Location = new Point(535, 108);
            delete_reserva_dni_cliente.Name = "delete_reserva_dni_cliente";
            delete_reserva_dni_cliente.Size = new Size(276, 34);
            delete_reserva_dni_cliente.TabIndex = 57;
            // 
            // label38
            // 
            label38.AutoSize = true;
            label38.Location = new Point(400, 114);
            label38.Name = "label38";
            label38.Size = new Size(108, 28);
            label38.TabIndex = 56;
            label38.Text = "DNI cliente";
            // 
            // button3
            // 
            button3.Location = new Point(452, 337);
            button3.Name = "button3";
            button3.Size = new Size(172, 42);
            button3.TabIndex = 55;
            button3.Text = "Eliminar reserva";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // label39
            // 
            label39.AutoSize = true;
            label39.Location = new Point(497, 59);
            label39.Name = "label39";
            label39.Size = new Size(86, 28);
            label39.TabIndex = 54;
            label39.Text = "Reservas";
            // 
            // delete_reserva_begin_date
            // 
            delete_reserva_begin_date.Location = new Point(535, 148);
            delete_reserva_begin_date.Name = "delete_reserva_begin_date";
            delete_reserva_begin_date.Size = new Size(276, 34);
            delete_reserva_begin_date.TabIndex = 53;
            // 
            // label40
            // 
            label40.AutoSize = true;
            label40.Location = new Point(394, 151);
            label40.Name = "label40";
            label40.Size = new Size(114, 28);
            label40.TabIndex = 52;
            label40.Text = "Fecha inicio";
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1228, 704);
            Controls.Add(sub_windows);
            Controls.Add(label1);
            Name = "MainForm";
            Text = "Administrador de reservas de coches";
            sub_windows.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            tabControl1.ResumeLayout(false);
            tabUpdateAgencias.ResumeLayout(false);
            tabUpdateAgencias.PerformLayout();
            tabUpdateClientes.ResumeLayout(false);
            tabUpdateClientes.PerformLayout();
            tabUpdateCoches.ResumeLayout(false);
            tabUpdateCoches.PerformLayout();
            tabUpdateReservas.ResumeLayout(false);
            tabUpdateReservas.PerformLayout();
            tabPage3.ResumeLayout(false);
            tabPage3.PerformLayout();
            tabControl2.ResumeLayout(false);
            tabPage5.ResumeLayout(false);
            tabPage5.PerformLayout();
            tabPage6.ResumeLayout(false);
            tabPage6.PerformLayout();
            tabPage7.ResumeLayout(false);
            tabPage7.PerformLayout();
            tabPage8.ResumeLayout(false);
            tabPage8.PerformLayout();
            tabPage4.ResumeLayout(false);
            tabPage4.PerformLayout();
            tabControl3.ResumeLayout(false);
            tabPage9.ResumeLayout(false);
            tabPage9.PerformLayout();
            tabPage10.ResumeLayout(false);
            tabPage10.PerformLayout();
            tabPage11.ResumeLayout(false);
            tabPage11.PerformLayout();
            tabPage12.ResumeLayout(false);
            tabPage12.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TabControl sub_windows;
        private TabPage tabPage1;
        private Label label2;
        private DataGridView dataGridView1;
        private TabPage tabPage2;
        private ComboBox comboBox_table_selected;
        private TabPage tabPage3;
        private TabControl tabControl1;
        private TabPage tabUpdateAgencias;
        private TabPage tabUpdateClientes;
        private TabPage tabUpdateCoches;
        private TabPage tabUpdateReservas;
        private Label label3;
        private Label label4;
        private TabControl tabControl2;
        private TabPage tabPage5;
        private TabPage tabPage6;
        private TabPage tabPage7;
        private TabPage tabPage8;
        private TabPage tabPage4;
        private Label label5;
        private TabControl tabControl3;
        private TabPage tabPage9;
        private TabPage tabPage10;
        private TabPage tabPage11;
        private TabPage tabPage12;
        private Button delete_clientes;
        private Label label8;
        private TextBox delete_name_cliente;
        private TextBox delete_dni_cliente;
        private Label label7;
        private Label label6;
        private Button button_delete_agencia;
        private Label label9;
        private TextBox delete_agencia_name;
        private Label label10;
        private Label label11;
        private Button button_delete_coche;
        private Label label12;
        private TextBox delete_coche_matricula;
        private Label label13;
        private Button button_update_agencia;
        private Label label14;
        private TextBox update_agencias_old_name;
        private Label label15;
        private TextBox insert_agencia_address;
        private Label label17;
        private Button insert_agencia;
        private Label label18;
        private TextBox insert_agencia_name;
        private Label label19;
        private TextBox insert_coches_marca;
        private Label label24;
        private TextBox insert_coches_color;
        private Label label23;
        private TextBox insert_coches_modelo;
        private Label label22;
        private TextBox insert_coches_matricula;
        private Label label16;
        private Button button2;
        private Label label20;
        private TextBox insert_coches_garaje;
        private Label label21;
        private TextBox insert_cliente_avalador;
        private Label label25;
        private TextBox insert_cliente_phone;
        private Label label26;
        private TextBox insert_cliente_address;
        private Label label27;
        private TextBox insert_cliente_dni;
        private Label label28;
        private Button button_insert_cliente;
        private Label label29;
        private TextBox insert_cliente_name;
        private Label label30;
        private TextBox insert_reserva_agencia_name;
        private Label label31;
        private TextBox insert_reserva_costo;
        private Label label32;
        private TextBox insert_reserva_final_date;
        private Label label33;
        private TextBox insert_reserva_dni_client;
        private Label label34;
        private Button button_insert_reserva;
        private Label label35;
        private TextBox insert_reserva_begin_date;
        private Label label36;
        private TextBox delete_reserva_agencia_name;
        private Label label37;
        private TextBox delete_reserva_dni_cliente;
        private Label label38;
        private Button button3;
        private Label label39;
        private TextBox delete_reserva_begin_date;
        private Label label40;
        private TextBox update_agencias_new_address;
        private Label label41;
        private TextBox update_agencias_new_name;
        private Label label42;
        private TextBox update_client_new_dni_avalador;
        private Label label43;
        private TextBox update_client_new_phone;
        private Label label44;
        private TextBox update_client_new_address;
        private Label label45;
        private TextBox update_client_dni;
        private Label label46;
        private Button button_update_client;
        private Label label47;
        private TextBox update_client_new_name;
        private Label label48;
        private TextBox update_car_new_marca;
        private Label label49;
        private TextBox update_car_new_color;
        private Label label50;
        private TextBox update_car_new_model;
        private Label label51;
        private TextBox update_car_new_matricula;
        private Label label52;
        private Button button_update_car;
        private Label label53;
        private TextBox update_car_new_garage;
        private Label label54;
        private TextBox update_car_id;
        private Label label55;
        private TextBox update_reservas_new_agencia_name;
        private Label label56;
        private TextBox update_reservas_new_cost;
        private Label label57;
        private TextBox update_reservas_new_end_date;
        private Label label58;
        private TextBox update_reservas_new_dni_client;
        private Label label59;
        private Button button_update_reservas;
        private Label label60;
        private TextBox update_reservas_new_begin_date;
        private Label label61;
        private TextBox update_reservas_id;
        private Label label62;
        private Label label64;
        private Label label63;
        private Label label66;
        private Label label65;
        private Label label67;
        private Label label68;
        private Label label69;
    }
}